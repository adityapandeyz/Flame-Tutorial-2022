package com.example.flame_setup_tutorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
